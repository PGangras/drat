## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  echo = TRUE,
  warning = FALSE,
  message = FALSE,
  prompt = FALSE,
  fig.pos = 'h',
  highlight = FALSE
)
knitr::knit_theme$set("edit-matlab")

## ----set-options, echo=FALSE------------------------------------------------------------------------------------------
options(width = 120)

## ----echo = FALSE, out.width = "60%", fig.align = "center"------------------------------------------------------------
knitr::include_graphics("ragp_flow_chart.svg")

## ----libraries--------------------------------------------------------------------------------------------------------
library(dplyr)
library(seqinr)
library(eulerr)
library(ragp)
library(ggplot2)

## ----data-------------------------------------------------------------------------------------------------------------
library(ragp)
data(at_nsp)
summary(at_nsp)

## ----input 1----------------------------------------------------------------------------------------------------------
data(at_nsp) #a data frame of 2700 Arabidopsis protein sequences 
input1 <- scan_ag(sequence = at_nsp$sequence,
                  id = at_nsp$Transcript.id) 

## ----input 2, eval = FALSE--------------------------------------------------------------------------------------------
#  input2 <- scan_ag(data = at_nsp,
#                    sequence = "sequence",
#                    id = "Transcript.id")

## ----input 3, eval = FALSE--------------------------------------------------------------------------------------------
#  input3 <- scan_ag(data = at_nsp,
#                    sequence = sequence,
#                    id = Transcript.id)

## ----input 4, eval = FALSE--------------------------------------------------------------------------------------------
#  #write a FASTA file
#  seqinr::write.fasta(sequence = strsplit(at_nsp$sequence, ""),
#                      name = at_nsp$Transcript.id, file = "at_nsp.fasta")
#  
#  #read a FASTA file
#  At_seq_fas <- read.fasta("at_nsp.fasta",
#                           seqtype =  "AA",
#                           as.string = TRUE)
#  
#  input4 <- scan_ag(data = At_seq_fas)

## ----input 5, eval = FALSE--------------------------------------------------------------------------------------------
#  input5 <- scan_ag(data = "at_nsp.fasta")

## ----hidden, echo = FALSE---------------------------------------------------------------------------------------------
vigfiles <- readRDS("vig_files.rds")
id_nsp <- vigfiles$id_nsp
at_hmm <- vigfiles$at_hmm
nsp_signalp <- vigfiles$nsp_signalp
at_gpi <- vigfiles$at_gpi
at_gpi_pred <- vigfiles$at_gpi_pred
at_nsp2 <- dplyr::filter(at_nsp, Transcript.id %in% id_nsp)


## ----SignalP1, eval = FALSE-------------------------------------------------------------------------------------------
#  nsp_signalp <- get_signalp(at_nsp,
#                             sequence,
#                             Transcript.id)

## ----SignalP2---------------------------------------------------------------------------------------------------------
head(nsp_signalp[,-c(1,10)]) #omitting columns "id" and "Networks.used"

## ----TargetP1, eval = FALSE-------------------------------------------------------------------------------------------
#  nsp_targetp <- get_targetp(at_nsp,
#                             sequence,
#                             Transcript.id)
#  
#  nsp_phobius <- get_phobius(at_nsp,
#                             sequence,
#                             Transcript.id)

## ----euler, eval = FALSE----------------------------------------------------------------------------------------------
#  set.seed(5)
#  bind_cols(nsp_signalp, nsp_targetp, nsp_phobius) %>%
#    select(is.phobius, is.targetp, is.signalp) %>%
#    euler(shape = "ellipse", input = "disjoint") %>%
#    plot(quantities = T)

## ----echo = FALSE, out.width = "40%", fig.align = "center"------------------------------------------------------------
knitr::include_graphics("eulerr.svg")

## ----euler2, eval = FALSE---------------------------------------------------------------------------------------------
#  bind_cols(nsp_signalp, nsp_targetp, nsp_phobius) %>%
#    select(is.phobius, is.targetp, is.signalp, id) %>%
#    mutate(vote = rowSums(.[,1:3])) %>%
#    filter(vote >= 2) %>%
#    pull(id) -> id_nsp
#  
#  at_nsp2 <- filter(at_nsp, Transcript.id %in% id_nsp)

## ----predict 1--------------------------------------------------------------------------------------------------------
at_hyp <- predict_hyp(data = at_nsp2,
                      sequence = sequence,
                      id = Transcript.id)

## ----filter hyp show--------------------------------------------------------------------------------------------------
head(at_hyp$prediction)

## ----predict 2, eval = FALSE------------------------------------------------------------------------------------------
#  at_hyp2 <- predict_hyp(data = at_nsp2,
#                         sequence = sequence,
#                         id = Transcript.id,
#                         tprob = 0.6)

## ----filter hyp three or more-----------------------------------------------------------------------------------------
at_hyp$prediction %>%
  group_by(id) %>%
  summarise(n = sum(HYP == "Yes")) %>%
  filter(n >= 3) %>%
  pull(id) -> at_3hyp

at_nsp2 %>%
  filter(Transcript.id %in% at_3hyp) -> at_nsp_3hyp

## ----scan_ag----------------------------------------------------------------------------------------------------------
scaned_at <- scan_ag(data = at_nsp_3hyp,
                     sequence,
                     Transcript.id)

## ----scan_ag2---------------------------------------------------------------------------------------------------------
scaned_at  %>%
  mutate(sequence = strtrim(sequence, 55)) %>%
  select(-3) %>% #omitting 3rd column
  filter(id == "AT2G14890.1")

## ----scan_ag3---------------------------------------------------------------------------------------------------------
scaned_at <- scan_ag(data = at_hyp$sequence,
                     sequence,
                     id)

## ----scan_ag4---------------------------------------------------------------------------------------------------------
scaned_at  %>%
  mutate(sequence = strtrim(sequence, 55)) %>%
  select(-3) %>% 
  filter(id == "AT2G14890.1")

## ----scan_ag5---------------------------------------------------------------------------------------------------------
scaned_at <- scan_ag(data = at_hyp$sequence,
                     sequence,
                     id,
                     exclude_ext = "yes")

scaned_at  %>%
  mutate(sequence = strtrim(sequence, 55)) %>%
  select(-3) %>%
  filter(id == "AT2G14890.1")

## ----scan_ag6---------------------------------------------------------------------------------------------------------
scaned_at <- scan_ag(data = at_hyp$sequence,
                     sequence,
                     id,
                     exclude_ext = "all")

scaned_at  %>%
  mutate(sequence = strtrim(sequence, 55)) %>%
  select(-3) %>%
  filter(id == "AT2G14890.1")

## ----scan_ag7---------------------------------------------------------------------------------------------------------
scaned_at <- scan_ag(data = at_hyp$sequence,
                     sequence,
                     id,
                     type = "conservative")

scaned_at  %>%
  mutate(sequence = strtrim(sequence, 55)) %>%
  select(-3) %>%
  filter(id == "AT2G14890.1")

## ----scan_ag8, echo = FALSE-------------------------------------------------------------------------------------------
scaned_at <- scan_ag(data = at_hyp$sequence,
                     sequence,
                     id)


## ----scan_ag9---------------------------------------------------------------------------------------------------------
scaned_at_nsp2 <- scan_ag(data = at_nsp2,
                          sequence,
                          Transcript.id)

sum(scaned_at_nsp2$total_length != 0)

## ----maab 1-----------------------------------------------------------------------------------------------------------
maab_at <- maab(at_nsp_3hyp,
                sequence,
                Transcript.id)

## ----maab 2-----------------------------------------------------------------------------------------------------------
maab_at %>%
  filter(maab_class != "0") %>%
  select(-ends_with("percent")) %>% #omitting columns ending with "percent"
  head 

## ----maab 4, results ="hide", eval = TRUE-----------------------------------------------------------------------------
maab_at <- maab(at_nsp_3hyp,
                sequence,
                Transcript.id,
                get_gpi = "bigpi")

## ----maab 5-----------------------------------------------------------------------------------------------------------
maab_at %>%
  filter(maab_class != "0") %>%
  select(-ends_with("percent")) %>% 
  head 

## ----hmmscan 1, eval = FALSE------------------------------------------------------------------------------------------
#  at_hmm <- get_hmm(at_nsp_3hyp,
#                    sequence,
#                    Transcript.id)

## ----hmmscan 2--------------------------------------------------------------------------------------------------------
head(at_hmm[,-c(4, 5, 8, 9, 11:13)])

## ----big_pi, eval = FALSE---------------------------------------------------------------------------------------------
#  at_gpi <- get_big_pi(at_nsp_3hyp,
#                       sequence,
#                       Transcript.id)

## ----big_pi2----------------------------------------------------------------------------------------------------------
head(at_gpi)

## ----pred_gpi, eval = FALSE-------------------------------------------------------------------------------------------
#  at_gpi_pred <- get_pred_gpi(at_nsp_3hyp,
#                              sequence,
#                              Transcript.id)

## ----pred_gpi2--------------------------------------------------------------------------------------------------------
head(at_gpi_pred)

## ----espritz, eval = FALSE--------------------------------------------------------------------------------------------
#  at_espritz <- get_espritz(at_nsp_3hyp,
#                            sequence,
#                            Transcript.id,
#                            model = "NMR")

## ----plot_prot1, eval = FALSE-----------------------------------------------------------------------------------------
#  ind <- c(20, 23, 34, 52, 80, 127, 345) #some indexes which will be used to filter sequences
#  p1 <- plot_prot(sequence = at_nsp$sequence[ind],
#                  id = at_nsp$Transcript.id[ind],
#                  dom_sort = "ievalue") #to plot domains by independent e-value (lower on top)
#  
#  p1

## ----echo = FALSE, out.width = "100%", fig.align = "center"-----------------------------------------------------------
knitr::include_graphics("p1_evalue.svg")

## ----plot_prot2, eval = FALSE-----------------------------------------------------------------------------------------
#  p1 <- plot_prot(sequence = at_nsp$sequence[ind],
#                  id = at_nsp$Transcript.id[ind],
#                  dom_sort = "cba") #to plot domains by name, first on top, also check "abc"
#  
#  p1

## ----echo = FALSE, out.width = "100%", fig.align = "center"-----------------------------------------------------------
knitr::include_graphics("p1.svg")

## ----plot_prot3, eval = FALSE-----------------------------------------------------------------------------------------
#  p1 +
#    coord_equal(ratio = 50)

## ----echo = FALSE, out.width = "100%", fig.align = "center"-----------------------------------------------------------
knitr::include_graphics("p1_coord.svg")

## ----plot_prot4, eval = FALSE-----------------------------------------------------------------------------------------
#  p1 +
#    scale_fill_brewer(type = "div")

## ----echo = FALSE, out.width = "100%", fig.align = "center"-----------------------------------------------------------
knitr::include_graphics("p1_fill.svg")

## ----plot_prot5, eval = FALSE-----------------------------------------------------------------------------------------
#  p3 <- plot_prot(sequence = at_nsp$sequence[ind],
#                  id = at_nsp$Transcript.id[ind],
#                  hyp_col = "brown",
#                  ag_col = "orange",
#                  dom_sort = "cba")
#  p3

## ----echo = FALSE, out.width = "100%", fig.align = "center"-----------------------------------------------------------
knitr::include_graphics("p3.svg")

## ----plot_prot7, eval = FALSE-----------------------------------------------------------------------------------------
#  p1 +
#    scale_fill_brewer(type = "div")+
#    scale_color_brewer(type = "qual")

## ----echo = FALSE, out.width = "100%", fig.align = "center"-----------------------------------------------------------
knitr::include_graphics("p1_fill_color.svg")

## ----plot_prot_disorder, eval = FALSE---------------------------------------------------------------------------------
#  p2 <- plot_prot(at_nsp$sequence[ind],
#                  at_nsp$Transcript.id[ind],
#                  gpi = "predgpi",
#                  disorder = TRUE)
#  p2

## ----echo = FALSE, out.width = "100%", fig.align = "center"-----------------------------------------------------------
knitr::include_graphics("p2_dis.svg")

## ----plot_prot8, eval = FALSE-----------------------------------------------------------------------------------------
#  p3 <- plot_prot(sequence = at_nsp$sequence[ind],
#                  id = at_nsp$Transcript.id[ind],
#                  hyp = FALSE,
#                  ag = FALSE,
#                  dom_sort = "cba")
#  p3

## ----echo = FALSE, out.width = "100%", fig.align = "center"-----------------------------------------------------------
knitr::include_graphics("p2.svg")

## ----plot_prot9, eval = FALSE-----------------------------------------------------------------------------------------
#  p1 +
#    annotate(geom = "text",
#             y = 6,
#             x = 100,
#             label = "look at all these TMs") +
#    annotate(geom = "point",
#             y = 4,
#             x = c(237, 240, 298),
#             shape = 21,
#             fill = "dodgerblue",
#             size = 3)

## ----echo = FALSE, out.width = "100%", fig.align = "center"-----------------------------------------------------------
knitr::include_graphics("p1_anno.svg")

